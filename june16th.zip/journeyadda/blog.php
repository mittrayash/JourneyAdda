<?php include'header.php'; ?>

<div class="container text-center pt50 pb50 about" style="margin-top:6%;">
     <h1>BLOG</h1>
		<h4 style="color:#000;">Write motto here or something interesting<br>
Two lines preferably</h4>

	<div class="row">
		<div class="pt30">
			
			
			<article class="blog-item col-md-4" style="float: left; list-style: none; position: relative;">
				<div class="blog-img"> 
						<a href="" class="" target="_blank"> 
						<img src="images/blog2.jpg" class="img-responsive">
						</a> 
					<div class="blog-desc"> 
						<div class="post-author"> 
							<span><img  title="Discover India" alt="Discover India" src="images/blog1.1.jpg">
							</span>
							<p> 
								<a href="" class="" target="_blank"> 5 Getaways In India To Beat The Heat This Summer </a>
							</p>
				
							<div class="blog-extra">
					
								<a class="read-more " href="" target="_blank">Read More</a>
							</div> 
						</div> 
					</div>
				</div>
			</article>
			
			<article class="blog-item col-md-4" style="float: left; list-style: none; position: relative;">
				<div class="blog-img"> 
						<a href="" class="" target="_blank"> 
						<img src="images/blog1.jpg" class="img-responsive">
						</a> 
					<div class="blog-desc"> 
						<div class="post-author"> 
							<span><img  title="Discover India" alt="Discover India" src="images/blog1.1.jpg">
							</span>
							<p> 
								<a href="" class="" target="_blank"> 5 Getaways In India To Beat The Heat This Summer </a>
							</p>
				
							<div class="blog-extra">
					
								<a class="read-more " href="" target="_blank">Read More</a>
							</div> 
						</div> 
					</div>
				</div>
			</article>
			
			<article class="blog-item col-md-4" style="float: left; list-style: none; position: relative;">
				<div class="blog-img"> 
						<a href="" class="" target="_blank"> 
						<img src="images/blog2.jpg" class="img-responsive">
						</a> 
					<div class="blog-desc"> 
						<div class="post-author"> 
							<span><img  title="Discover India" alt="Discover India" src="images/blog1.1.jpg">
							</span>
							<p> 
								<a href="" class="" target="_blank"> 5 Getaways In India To Beat The Heat This Summer </a>
							</p>
				
							<div class="blog-extra">
					
								<a class="read-more " href="" target="_blank">Read More</a>
							</div> 
						</div> 
					</div>
				</div>
			</article>
			
			<article class="blog-item col-md-4" style="float: left; list-style: none; position: relative;">
				<div class="blog-img"> 
						<a href="" class="" target="_blank"> 
						<img src="images/blog1.jpg" class="img-responsive">
						</a> 
					<div class="blog-desc"> 
						<div class="post-author"> 
							<span><img  title="Discover India" alt="Discover India" src="images/blog1.1.jpg">
							</span>
							<p> 
								<a href="" class="" target="_blank"> 5 Getaways In India To Beat The Heat This Summer </a>
							</p>
				
							<div class="blog-extra">
					
								<a class="read-more " href="" target="_blank">Read More</a>
							</div> 
						</div> 
					</div>
				</div>
			</article>
			
			<article class="blog-item col-md-4" style="float: left; list-style: none; position: relative;">
				<div class="blog-img"> 
						<a href="" class="" target="_blank"> 
						<img src="images/blog1.jpg" class="img-responsive">
						</a> 
					<div class="blog-desc"> 
						<div class="post-author"> 
							<span><img  title="Discover India" alt="Discover India" src="images/blog1.1.jpg">
							</span>
							<p> 
								<a href="" class="" target="_blank"> 5 Getaways In India To Beat The Heat This Summer </a>
							</p>
				
							<div class="blog-extra">
					
								<a class="read-more " href="" target="_blank">Read More</a>
							</div> 
						</div> 
					</div>
				</div>
			</article>
			
			<article class="blog-item col-md-4" style="float: left; list-style: none; position: relative;">
				<div class="blog-img"> 
						<a href="" class="" target="_blank"> 
						<img src="images/blog1.jpg" class="img-responsive">
						</a> 
					<div class="blog-desc"> 
						<div class="post-author"> 
							<span><img  title="Discover India" alt="Discover India" src="images/blog1.1.jpg">
							</span>
							<p> 
								<a href="" class="" target="_blank"> 5 Getaways In India To Beat The Heat This Summer </a>
							</p>
				
							<div class="blog-extra">
					
								<a class="read-more " href="" target="_blank">Read More</a>
							</div> 
						</div> 
					</div>
				</div>
			</article>
			
		</div>
	</div>

</div>	
<?php include'footer.php'; ?>