<?php
$host="localhost";
$user="urjentup_adda";
   
     $pass="journey@adda123";
     $db="urjentup_journey";
	 $conn = mysqli_connect($host, $user, $pass,$db) or die(mysqli_error());
	
$database=mysqli_select_db($conn,$db)or die(mysqli_error());
	

	 
	 
	 
	 
	 
	 
	 
	 ?>