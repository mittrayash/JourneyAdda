 <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">

            <div class="">
              <p style="color:#fff;">Admin</p>
              <!--<a href="#"><i class="fa fa-circle text-success"></i> Online</a> -->
            </div>
          </div>
          
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <!--<li class="active treeview">
              <a href="dashboard.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              
            </li>-->
             <li class="treeview">
              <a href="discover_india.php">
                <i class="fa-file-o "></i>
                <span>Discover India</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
             
            
              
              
            </li>
            	<li class="treeview">
              <a href="package.php">
                <i class="fa fa-laptop"></i>
                <span>Packages</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a> </li>
              </li>
            	<li class="treeview">
              <a href="package_details.php">
                <i class="fa fa-laptop"></i>
                <span>Package Details</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a> </li>
             <li class="treeview">
              <a href="banner.php">
                <i class="fa-file-o "></i>
                <span>Index Banner</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              
              
            </li>
             </li>
            	<li class="treeview">
              <a href="power.php">
                <i class="fa fa-laptop"></i>
                <span>Power</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a> </li>
              
             </li>
            	<li class="treeview">
              <a href="shoot.php">
                <i class="fa fa-laptop"></i>
                <span>Shoot</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a> </li>
            
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>
