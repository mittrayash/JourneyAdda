<?php
require("connect.php");


if(!empty($_POST["country_id"])) {
	
	$query=mysqli_query($conn,"SELECT CityId,CityName FROM city WHERE CountryId = '" . $_POST["country_id"] . "'")or die(mysqli_error());
	?>
	
	<option value="">Select City</option>
	<?php
	  while ($row= mysqli_fetch_array ($query) )
	  {
		?>
   
		<option value="<?php echo $row ['CityId']; ?>"><?php echo $row ['CityName']; ?></option>
	   <?php 
   }
   ?>
   
<?php }   
?>
