<?php
error_reporting(0);
require("connect.php");
include("includes/header.php");
include("includes/left_sidebar.php"); 
	?>
<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
function getState(val) {
	
	
	$.ajax({
		
	type: "POST",
	url: "get_state.php",
	data:'country_id='+val,
	success: function(data){
		
		$("#ddlView").html(data);

	}
	
	});
}

function selectCountry(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>

<link rel="stylesheet" href="css/jquery-ui-1.10.2.custom.css" type="text/css" />
<script type="text/javascript" src="js/jquery-1.9.1.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.2.custom.js"></script>
<script type="text/javascript">
$(document).ready(function()
{
	$('#cal').datepicker();
});
</script>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Property Management
            <small>Add Property</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i>Home</a></li>
          <!--  <li class="active">Add Clinic</li> -->
          </ol>
        </section>
        <!-- Main content -->
        <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Add Property</h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form role="form" method="post" name="form" enctype="multipart/form-data">
                  <div class="box-body">
				  <div class="row col-md-6">
                    
					<div class="form-group">
                      <label for="PlayerName">Identifer Person:</label>
                      <input type="text" class="form-control" name="player_name"   required maxlength="30" placeholder="Player Name" style="width:70%">
                    </div>
					
					<div class="form-group">
                      <label for="NickName">Nick Name:</label>
                      <input type="text" class="form-control" name="nick_name"   required maxlength="30" placeholder="Nick Name" style="width:70%">
                    </div>
					
					<div class="form-group">
                      <label for="PlayerImage">Player Image:</label>
                      <input type="file" class="img" name="player_image"  accept="image/*" required maxlength="30" placeholder="Player Image" style="width:70%" id="player_image" >
                    </div>
					
					
					<div class="form-group">
                      <label for="PlayerDescription">Player Description:</label>
                      <input type="text" class="form-control" name="player_description"   required  placeholder="Player Description" style="height:150px; width:70%;">
                    </div>
					
					
					<div class="form-group">
                      <label for="PlayerImage">Player Gallery:</label>
                      <input type="file" class="img" name="player_gallery"  accept="image/*" required maxlength="30" placeholder="Player Gallery" style="width:70%" id="player_gallery">
                    </div>
					
					<div class="form-group">
                      <label for="PlayerImage">Player Video:</label>
                      <input type="file" class="img" name="player_video"  accept="video/*" required maxlength="30" placeholder="Player Video" style="width:70%" id="player_video">
                    </div>
					
					
					<div class="form-group">
                      <label for="Height">Height:</label>
                      <input type="text" class="form-control" name="height"   required maxlength="30" placeholder="Height" style="width:70%">
                    </div>

                       <div class="form-group">
                      <label for="Weight">Weight:</label>
                      <input type="text" class="form-control" name="weight"   required maxlength="30" placeholder="Weight" style="width:70%">
                      </div>
     
               <div class="form-group">
                      <label for="Position">Position:</label>
                      <input type="text" class="form-control" name="position"   required maxlength="30" placeholder="Position" style="width:70%">
                      </div>
					
					<div class="form-group">
                      <label for="education">Education:</label>
                      <input type="text" class="form-control" name="education"   required maxlength="30" placeholder="Education" style="width:70%">
                    </div>
					
					<div class="form-group">
                      <label for="Playerprofile">Player Profile:</label>
                      <input type="text" class="form-control" name="player_profile"   required maxlength="30" placeholder="Player Profile" style="width:70%">
                    </div>
					
					<div class="form-group">
                      <label for="strength">Strength:</label>
                      <input type="text" class="form-control" name="strength"   required maxlength="30" placeholder="Strength" style="width:70%">
                    </div>
					
					<div class="form-group">
                      <label for="Weakness">Weakness:</label>
                      <input type="text" class="form-control" name="weakness"   required maxlength="30" placeholder="Weakness" style="width:70%">
                    </div>
					
					<div class="form-group">
                      <label for="careerhigh">Career Heigh:</label>
                      <input type="text" class="form-control" name="career_high"   required maxlength="30" placeholder="Career Heigh" style="width:70%">
                    </div>
					
					<div class="form-group">
                      <label for="style">Style:</label>
                      <input type="text" class="form-control" name="style"   required maxlength="30" placeholder="Style" style="width:70%">
                    </div>
					
					<div class="form-group">
                      <label for="Quotes">Quotes:</label>
                      <input type="text" class="form-control" name="quotes"   required maxlength="30" placeholder="Quotes" style="width:70%">
                    </div>
					
				<div class="form-group">
                      <label for="exampleInputPassword1">Team:</label>
                   
							<select required id="team-list" name="team_id" class="form-control" onChange="getState(this.value)" style="width:70%">
							<!--<select name="country" id="country-list" class="demoInputBox" onChange="getState(this.value);">-->
								<option value="0" disabled selected style='display:none;'>Select Team</option>
								 <?php
								  $query=mysqli_query($conn,"select * from  teams")or die(mysqli_error());
								  while ($row= mysqli_fetch_array ($query) )
								  {
									?>
							   
									<option value="<?php echo $row ['team_id']; ?>"><?php echo $row ['team_name']; ?></option>
								   <?php 
							   } ?>
							</select>
                </div>
					<div class="form-group">
                      <label for="exampleInputPassword1">sports:</label>
                   
							<select required id="sports-list" name="sports_id" class="form-control" onChange="getState(this.value)" style="width:70%">
							<!--<select name="country" id="country-list" class="demoInputBox" onChange="getState(this.value);">-->
								<option value="0" disabled selected style='display:none;'>Select Sports</option>
								 <?php
								  $query=mysqli_query($conn,"select * from sports_category")or die(mysqli_error());
								  while ($row= mysqli_fetch_array ($query) )
								  {
									?>
							   
									<option value="<?php echo $row ['sports_id']; ?>"><?php echo $row ['sports_name']; ?></option>
								   <?php 
							   } ?>
							</select>
                    </div>
					<div class="form-group">
                      <label for="DateOfBirth">Date Of Birth:</label>
                      <input id="cal" type="text" class="form-control" name="dob"   required maxlength="30" placeholder="Date Of Birth" style="width:70%">
                    </div>
					<div class="form-group">
                      <label for="TypeId">Id Type:</label>
                      <input type="text" class="form-control" name="id_type"   required maxlength="30" placeholder="Id Type" style="width:70%">
                    </div>
					<div class="form-group">
                      <label for="IdNumber">Id Number:</label>
                      <input type="text" class="form-control" name="id_number"   required maxlength="30" placeholder="ID Number" style="width:70%">
                    </div>
					<div class="form-group">
                      <label for="exampleInputPassword1">Country:</label>
                   
							<select required id="country-list" name="country_id" class="form-control" onChange="getState(this.value)" style="width:70%">
							<!--<select name="country" id="country-list" class="demoInputBox" onChange="getState(this.value);">-->
								<option value="0" disabled selected style='display:none;'>Select Country</option>
								 <?php
								  $query=mysqli_query($conn,"select * from  country")or die(mysqli_error());
								  while ($row= mysqli_fetch_array ($query) )
								  {
									?>
							   
									<option value="<?php echo $row ['countryid']; ?>"><?php echo $row ['countryname']; ?></option>
								   <?php 
							   } ?>
							</select>
                    </div>
					<div class="form-group">
                      <label for="exampleInputPassword1">City:</label>
					   <select name="city_id" id="ddlView" class="form-control" style="width:70%">
						<option>Select City</option>
						
						</select>
                    </div> 
					
					<div class="form-group">
                      <label for="NoOfGoals">No Of Matches:</label>
                      <input type="text" class="form-control" name="no_of_matches"   required maxlength="30" placeholder="No Of Matches" style="width:70%">
                    </div>
															
                  </div>
                  </div><!-- /.box-body -->
                  <div class="box-footer">
				  <center>
				      <input type="submit" name="addplayer" class="btn btn-primary" value="Save" onClick = "return Checkfiles()" />	
					 <input type="reset" value="Reset" class="btn btn-primary Add"/>
                  </center>
				  </div>
				  
				 <script type="text/javascript">
					function Checkfiles()
					{
						var fup = document.getElementById('player_image');
						var fileName = fup.value;
						var ext = fileName.substring(fileName.lastIndexOf('.') + 1);

					if(ext =="png" || ext=="gif" || ext=="jpeg" || ext=="jpg")
					{
						return playergallery();
						
					}
					else
					{
						alert("Upload Images only");
						return false;
					}
					function playergallery()
						{
							
						  	var fup1 = document.getElementById('player_gallery');
						    var fileName1 = fup1.value;
						    var ext1 = fileName1.substring(fileName1.lastIndexOf('.') + 1);
							
							if(ext1 =="png" || ext1=="gif" || ext1=="jpeg" || ext1=="jpg")
							{
								return playervideo();								
							}
							else
							{
								alert("Upload Images only");
								return false;
							}
							
							function playervideo()
						     {
							
								var fup3 = document.getElementById('player_video');
								var fileName3 = fup3.value;
								var ext3 = fileName3.substring(fileName3.lastIndexOf('.') + 1);
								
								if(ext3 =="mp4" || ext3=="avi" || ext3=="mov" || ext3=="3gp" || ext3=="mpeg" || ext3=="3GPP Audio/Video")
								{
									return true;
								}
								else
								{
									alert("Upload videos only");
									return false;
								}
							
						}
						}
					}
				</script>
                </form>
              </div><!-- /.box -->
            </div><!--/.col (left) -->
          </div>   <!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
     <?php
include("includes/footer.php"); 
  // -- Add Data --
  if(isset($_POST['addplayer']))
  {
	    $imageFileType1 = pathinfo($target_file1,PATHINFO_EXTENSION);
	    $target_dir1 = "uploadbracketCategory/";
	    $target_file1 = $target_dir1 . basename($_FILES["player_image"]["name"]);
	    $a_file1 = $_FILES["player_image"]["name"];
	    $temp1 = explode(".", $_FILES["player_image"]["name"]);
	    $newfilename1 = round(microtime(true)) . '.' . end($temp);		
	    move_uploaded_file($_FILES['player_image']['tmp_name'], "uploadbracketCategory/" .$_FILES["player_image"]['name']);
	   
	    $imageFileType2 = pathinfo($target_file2,PATHINFO_EXTENSION);
	    $target_dir2 = "uploadbracketCategory/";
	    $target_file2 = $target_dir2 . basename($_FILES["player_gallery"]["name"]);
	    $a_file2 = $_FILES["player_gallery"]["name"];
	    $temp2 = explode(".", $_FILES["player_gallery"]["name"]);
	    $newfilename2 = round(microtime(true)) . '.' . end($temp2);		
	    move_uploaded_file($_FILES['player_gallery']['tmp_name'], "uploadbracketCategory/" .$_FILES["player_gallery"]['name']);
	    
		
		$imageFileType3 = pathinfo($target_file3,PATHINFO_EXTENSION);
	    $target_dir3 = "uploadbracketCategory/";
	    $target_file3 = $target_dir3 . basename($_FILES["player_video"]["name"]);
	    $a_file3 = $_FILES["player_video"]["name"];
	    $temp3 = explode(".", $_FILES["player_video"]["name"]);
	    $newfilename3 = round(microtime(true)) . '.' . end($temp3);		
	    move_uploaded_file($_FILES['player_video']['tmp_name'], "uploadbracketCategory/" .$_FILES["player_video"]['name']);
		
		
		
   
    $a_Player_Name=$_POST['player_name'];
	$a_Nick_Name = $_POST['nick_name'];
	$a_Player_Description=$_POST['player_description'];
	$a_Height = $_POST['height'];
    $a_Weight = $_POST['weight'];
    $a_Position = $_POST['position'];
	$a_Education = $_POST['education'];
	$a_Player_Profile = $_POST['player_profile'];
	$a_Strength = $_POST['strength'];
	$a_Weakness = $_POST['weakness'];
	$a_Career_High = $_POST['career_high'];
	$a_Style=$_POST['style'];
	$a_Quotes=$_POST['quotes'];
	$a_Team_id=$_POST['team_id'];
	$a_Sports_id=$_POST['sports_id'];
	$a_DOB=$_POST['dob'];
    $a_Id_Type=$_POST['id_type'];
	$a_Id_Number=$_POST['id_number'];
    $a_Country_Id=$_POST['country_id'];
	$a_City_Id=$_POST['city_id'];
	$a_No_Of_Matches=$_POST['no_of_matches'];

$sql="INSERT INTO players values('','$a_Player_Name','$a_Nick_Name','$a_file1','$a_Player_Description','$a_file2','$a_file3','$a_Height','$a_Weight','$a_Position','$a_Education','$a_Player_Profile','$a_Strength','$a_Weakness','$a_Career_High','$a_Style','$a_Quotes','$a_DOB','$a_Team_id','$a_Sports_id','$a_Id_Number','$a_Country_Id','$a_City_Id','$a_Id_Type','$a_No_Of_Matches','','','','','','','','',now(),now(),1)";

 		if (mysqli_query($conn,$sql)) 
		{
			
	        echo "<script type=\"text/javascript\">window.location.href = 'manage_player.php';</script>";
            exit;
		}
		else 
		{
			?> <p style="margin-left:200px">
		   <?php 
			 echo "Not added player try again"; ?></p>
			 <?php 
		}
	  }
?>
  </body>
</html>